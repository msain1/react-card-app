import Card from './card-component';
import './card-style.css'

const App = () => {
  const cardImageUrl = require('./images/card-img.png');
  const cardTitle = 'Lizard';
  const cardDescription = 'Chevrolet is an American automobile division of the American manufacturer General Motors. Louis Chevrolet, Arthur Chevrolet and ousted General Motors founder William C. Durant started the company on November 3, 1911 as the Chevrolet Motor Car Company.';
  const cardButtons = [
    {
      text: 'SHARE',
      onClick: () => {
        // Handle button 1 click
      },
    },
    {
      text: 'LEARN MORE',
      onClick: () => {
        // Handle button 2 click
      },
    },
  ];

  return (
    <div className='container'>
      <Card
        imageUrl={cardImageUrl}
        title={cardTitle}
        description={cardDescription}
        buttons={cardButtons}
      />
    </div>
  );
};

export default App;