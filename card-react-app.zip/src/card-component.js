import React from 'react';

// Card Image component
const CardImage = ({ imageUrl }) => {
  return <img src={imageUrl} alt="Card" />;
};

// Card Title component
const CardTitle = ({ title }) => {
  return <h2>{title}</h2>;
};

// Card Description component
const CardDescription = ({ description }) => {
  return <p>{description}</p>;
};

// Card Buttons component
const CardButtons = ({ buttons }) => {
    return (
      <div>
        {buttons.map((button, index) => (
          <button key={index} onClick={button.onClick}>
            {button.text}
          </button>
        ))}
      </div>
    );
  };

// Card component
const Card = ({ imageUrl, title, description, buttons }) => {
  return (
    <div className="card">
      <CardImage imageUrl={imageUrl} />
      <div className="card-content">
        <CardTitle title={title} />
        <CardDescription description={description} />
        <CardButtons buttons={buttons} />
      </div>
    </div>
  );
};

export default Card;
